using Godot;
using System;

public partial class CarController : RigidBody2D
{
    // Public variables you can adjust in the editor
    public float accelerationFactor = 30.0f;
    public float turnFactor = 3.5f;

    private float _accelerationInput = 0;
    private float _steeringInput = 0;

    public override void _PhysicsProcess(double delta)
    {
        // 1. Get player input
        // Godot's Input.GetAxis() combines two actions into a single float (-1 to 1)
        _steeringInput = Input.GetAxis("left", "right");

        // 2. Apply Engine Force
        // This force moves the car forward/backward.
        // We get the forward vector (Y-axis) of the car's GlobalTransform,
        // multiply it by the acceleration input and factor, and then apply the force.
        Vector2 engineForceVector = this.GlobalTransform.Y * _accelerationInput * accelerationFactor;
        this.ApplyForce(engineForceVector);

        // 3. Apply Steering Torque
        // This is the correct way to handle steering for a RigidBody2D.
        // Apply a rotational force (torque) based on steering input and a turn factor.
        // The negative sign is often needed to make the steering intuitive (left turns left).
        this.ApplyTorque(_steeringInput * -turnFactor);
    }
}