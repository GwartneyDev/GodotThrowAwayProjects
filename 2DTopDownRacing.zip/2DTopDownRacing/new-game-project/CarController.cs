using Godot;
using System;

public partial class CarController : RigidBody2D
{

    public float accelerationFactor = 30.0f;
    public float turnFactor = 3.5f;

    float accelerationInput = 0;
    float steeringInput = 0;

    float rotationAngle = 0;

    private RigidBody2D _rigidBody2d;

    public override void _Ready()
    {
        _rigidBody2d = GetNode<RigidBody2D>("RigidBody2d");
    }
}
